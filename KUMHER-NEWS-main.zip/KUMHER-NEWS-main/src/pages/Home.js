import React from 'react'
import Allpost from '../component/Allpost'
import Herosection from '../component/Herosection'

const Home = () => {
  return (
    <div>
        <Herosection/>
        <Allpost/>
    </div>
  )
}

export default Home