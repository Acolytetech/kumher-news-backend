import { post } from "./post";
import { heroSection } from "./herosection";
import { category } from "./category";

export const schemaTypes = [ post , heroSection,category]
